<?php
namespace Elementor;
extract($settings); 
use Bzotech_Template;
?>
<?php echo '<div '.$wdata->get_render_attribute_string( 'elbzotech-wrapper' ).'>';?>
    <?php echo '<div '.$wdata->get_render_attribute_string( 'elbzotech-wrapper-slider' ).'>';?>
        <?php echo '<div '.$wdata->get_render_attribute_string( 'elbzotech-inner' ).'>';?>
            <?php 
            foreach (  $list_testimonial as $key => $item ) {

                $wdata->add_render_attribute( 'elbzotech-item', 'class', 'wslider-item elementor-repeater-item-'.$item['_id'] );
                echo '<div '.$wdata->get_render_attribute_string( 'elbzotech-item' ).'><div class="item-slider-'.$style.'">';
                    
                    echo '<div class="flex-wrapper">';
                        if(!empty($item['image']['url'])) {
                            if($item['link']['is_external']) $wdata->add_render_attribute( 'img-link', 'target', "_blank");
                            if($item['link']['nofollow']) $wdata->add_render_attribute( 'img-link', 'rel', "nofollow");
                            
                            if($item['link']['url']) $wdata->add_render_attribute( 'img-link', 'href', $item['link']['url']);

                            echo '<div class="info-wrap"><a '.$wdata->get_render_attribute_string('img-link').' class="img-wrap">';
                            echo Group_Control_Image_Size::get_attachment_image_html( $list_testimonial[$key], 'thumbnail', 'image' );
                            echo '</a>';
                            if(!empty($item['title'])) echo '<h3 class="font-title title20 font-semibold">'.$item['title'].'</h3>';
                            if(!empty($item['description'])) echo '<p class="desc title14">'.$item['description'].'</p>';
                            echo '</div>';
                        }
                        echo '<div class="content-wrap">';
                           
                            if(!empty($item['number_star'])) echo '<div class="product-rate"><div class="product-rating number-star_'.$item['number_star'].'"></div></div>';
                           if(!empty($item['content'])) echo  '<div class="content-slider-custom box-content-custom">'.bzotech_parse_text_editor( $item['content']).'</div>';
                        echo '</div>';
                    echo '</div>';
                   
                           
                echo '</div></div>';

                $wdata->remove_render_attribute( 'img-link', 'target', "_blank" );
                $wdata->remove_render_attribute( 'img-link', 'rel', "nofollow");
                $wdata->remove_render_attribute( 'img-link', 'href', $item['link']['url']);
                $wdata->remove_render_attribute( 'img-link', 'href', $item['image']['url']);
                $wdata->remove_render_attribute( 'elbzotech-item', 'class', 'elementor-repeater-item-'.$item['_id'] );
            }
            ?>
        </div>
    </div>
    <?php if ( $slider_navigation !== '' ):?>
        <div class="bzotech-swiper-navi">
            <div class="swiper-button-nav swiper-button-next"><?php Icons_Manager::render_icon( $slider_icon_next, [ 'aria-hidden' => 'true' ] );?></div>
            <div class="swiper-button-nav swiper-button-prev"><?php Icons_Manager::render_icon( $slider_icon_prev, [ 'aria-hidden' => 'true' ] );?></div>
        </div>
    <?php endif?>
    <?php if ( $slider_pagination !== '' ):?>
        <div class="swiper-pagination"></div>
    <?php endif?>
    <?php if ( $slider_scrollbar !== '' ):?>
        <div class="swiper-scrollbar"></div>
    <?php endif?>
</div>
